
    chrome.proxy.settings.set({
      value: {
        mode: "fixed_servers",
        rules: {
          singleProxy: {
            scheme: "http",
            host: "brd.superproxy.io",
            port: parseInt("33335")
          },
          bypassList: ["localhost"]
        }
      },
      scope: "regular"
    }, function() {});

    // 인증 요청 처리
    chrome.webRequest.onAuthRequired.addListener(
      function(details) {
        return {
          authCredentials: {
            username: "brd-customer-hl_b3f40cdf-zone-residential_proxy1",
            password: "7go3fpwhqdtf"
          }
        };
      },
      {urls: ["<all_urls>"]},
      ['blocking']
    );
    